﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sound1 : MonoBehaviour
{
    void Start()
    {
        aus1 = GetComponent<AudioSource>();
    }

    void Update()
    {
        
    }

    public static AudioSource aus1;
}
