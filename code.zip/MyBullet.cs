﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MyBullet : MonoBehaviour
{
    void Start()
    {
        Invoke("SelfDestroy", 3f);
        Sound2.aus2.Play();
    }

    void Update()
    {
        transform.Translate(transDir);

    }



    public Vector3 transDir = Vector3.zero;


    private void OnCollisionEnter(Collision collision)
    {


        if (collision.gameObject.tag == "Robot") { }// Debug.Log("robot");
        // else Invoke("SelfDestroy", 0.1f);
        else
        {
            // Debug.Log("norobot");
            Sound1.aus1.Play();

            GameObject go=Instantiate(bulletboom);
            go.transform.position = transform.position;
            Debug.Log(transform.position);

            CharaCon cc = CharaCon.avatar;
            Vector3 avatarpos = cc.transform.position;
            float dis = (avatarpos.x - transform.position.x) * (avatarpos.x - transform.position.x) + (avatarpos.y - transform.position.y) * (avatarpos.y - transform.position.y);
            if (dis < 4)
            {
                Vector3 dir = CharaCon.avatar.transform.position - transform.position;
                dir.z = 0;
                dir = Vector3.Normalize(dir) * 0.4f;

                CharaCon.avatar.gameObject.GetComponent<CharaCon>().AddCharge(dir / 2);
            }

            Destroy(gameObject);
        }

    }

    public GameObject bulletboom;

    void SelfDestroy()
    {
        Destroy(gameObject);
    }

    private void OnCollisionExit(Collision collision)
    {
        if (collision.gameObject.tag == "Robot") {
            Debug.Log("robot");

           Rigidbody rb= gameObject.AddComponent<Rigidbody>();
            rb.useGravity = false;
            rb.freezeRotation = true;
            rb.collisionDetectionMode = CollisionDetectionMode.Continuous;
          // rb.
        }
    }
  
}
