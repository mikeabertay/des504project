﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Destination : MonoBehaviour
{
    void Start()
    {

    }

    void Update()
    {

    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "Robot")
        {
            Debug.Log("zzzzzzzzzzzzzzzz");
            LevelJumper.LevelJump();
        }
    }
}
