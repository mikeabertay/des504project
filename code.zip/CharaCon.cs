﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharaCon : MonoBehaviour
{

    public static CharaCon avatar;

    public GameObject sprite;

    float horizontalSpeed = 0;
    float horizontalStandard = 0.05f;
    float horizontalAcceleration = 0.005f;
    private void FixedUpdate()
    {

        if (!Input.GetKey(KeyCode.A) && !Input.GetKey(KeyCode.D)) horizontalSpeed = 0;


        if (Input.GetKey(KeyCode.A))
        {
            horizontalSpeed -= horizontalAcceleration;
            if (horizontalSpeed < -horizontalStandard) horizontalSpeed = -horizontalStandard;
            if (!isOnGround) horizontalSpeed = -horizontalStandard;
            if (isBumped) if (!bumpobjleft) horizontalSpeed = 0;



            GetComponent<CharacterController>().Move(new Vector3(horizontalSpeed, 0, 0));
            sprite.transform.localScale = new Vector3(-1, sprite.transform.localScale.y, sprite.transform.localScale.z);
        }
        else if (Input.GetKey(KeyCode.D))
        {
            horizontalSpeed += horizontalAcceleration;
            if (horizontalSpeed > horizontalStandard) horizontalSpeed = horizontalStandard;
            if (!isOnGround) horizontalSpeed = horizontalStandard;
            if (isBumped) if (bumpobjleft) horizontalSpeed = 0;

            GetComponent<CharacterController>().Move(new Vector3(horizontalSpeed, 0, 0));
            sprite.transform.localScale = new Vector3(1, sprite.transform.localScale.y, sprite.transform.localScale.z);
        }







        if (chargelist.Count > 0)
        {
            allcharge = Vector3.zero;

            foreach (object obj in chargelist)
            {
                DataCharge cd = obj as DataCharge;
                if (cd != null)
                {
                    if (cd.times > 0)
                    {

                        allcharge += cd.dir;
                        cd.times--;
                        if (cd.type == DataCharge.PowerType.bullet) if (firetimes >= 2) firetimes = 1;
                    }
                }
            }

            bias = 0;
            for (int i = 0; i < chargelist.Count; i++)
            {
                DataCharge cd = chargelist[i - bias] as DataCharge;
                if (cd.times <= 0)
                {
                    chargelist.RemoveAt(i - bias);

                    bias++;
                }
            }

            if (isOnGround) if (allcharge.y < 0) allcharge.y = 0;

            if (isBumped) allcharge.x = 0;

            GetComponent<CharacterController>().Move(allcharge);
            // if (transform.position.y < 0) transform.position = new Vector3(transform.position.x, 0, 0);




        }
        else
        {
            allcharge = Vector3.zero;
        }

        float dis2 = allcharge.y * allcharge.y;


        //gravity
        if (dis2 < 0.25f && dis2 > 0)
        {
            GetComponent<CharacterController>().Move(new Vector3(0, -0.05f, 0));
        }
        else
        {
            GetComponent<CharacterController>().Move(new Vector3(0, -0.1f, 0));
        }








        if (Input.GetMouseButtonDown(0))
        {
            if (firetimes > 0)
            {
                firetimes--;
                GameObject go = Instantiate(bullet);


                Vector3 dir = RayCastMonitor.rhpoint - transform.position;
                dir.z = 0;
                dir = Vector3.Normalize(dir) * 0.1f;
                go.GetComponent<MyBullet>().transDir = dir;

                go.transform.position = transform.position + 3.125f * dir;

                AddCharge(-dir / 2);
                /*
                                dir *= -10;

                                if (dir.y < 0) dir.y = 0;
                                transform.Translate(dir);*/
            }

        }
    }




    void Start()
    {
        avatar = this;
    }

    public int firetimes = 2;

    void Update()
    {
        // Debug.Log(GetComponent<MeshRenderer>().bounds.size.y);




    }

    Vector3 allcharge = Vector3.zero;
    int bias;

    public GameObject bullet;


    ArrayList chargelist = new ArrayList();

    public void AddCharge(Vector3 v)
    {
        DataCharge cd = new DataCharge();
        cd.dir = v;
        cd.times = 20;
        cd.type = DataCharge.PowerType.bullet;
        chargelist.Add(cd);
    }

    private void OnCollisionStay(Collision collision)
    {
        if (collision.gameObject.tag == "Ground")
        {
            firetimes = 2;
            isOnGround = true;
        }
        if (collision.gameObject.tag == "BlockPush" || collision.gameObject.tag == "BlockStatic" || collision.gameObject.tag == "BlockDestroy")
        {
            if (allcharge == Vector3.zero)
            {
                firetimes = 2;
                isOnGround = true;
            }
        }

        if (collision.gameObject.tag == "BlockStatic")
        {
            firetimes = 2;
            isOnGround = true;
            if (transform.position.y - collision.transform.position.y > (GetComponent<MeshRenderer>().bounds.size.y + collision.gameObject.GetComponent<MeshRenderer>().bounds.size.y) / 2 ||
                 transform.position.y - collision.transform.position.y < -(GetComponent<MeshRenderer>().bounds.size.y + collision.gameObject.GetComponent<MeshRenderer>().bounds.size.y) / 2)
            {
                isBumped = false;
            }
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "Ground")
        {
            if (transform.position.y - collision.transform.position.y >= (GetComponent<MeshRenderer>().bounds.size.y + collision.gameObject.GetComponent<MeshRenderer>().bounds.size.y) / 2)
            {

                firetimes = 2;
                isOnGround = true;

                //if (transform.position.y < 0) transform.position = new Vector3(transform.position.x, 0, 0);
            }

            /* if (transform.position.x - collision.transform.position.x < (GetComponent<MeshRenderer>().bounds.size.x + collision.gameObject.GetComponent<MeshRenderer>().bounds.size.x) / 2)
            {
                transform.position = new Vector3(collision.transform.position.x + (GetComponent<MeshRenderer>().bounds.size.x + collision.gameObject.GetComponent<MeshRenderer>().bounds.size.x) / 2, transform.position.y, transform.position.z);
            }
           
            if (transform.position.x - collision.transform.position.x > -(GetComponent<MeshRenderer>().bounds.size.x + collision.gameObject.GetComponent<MeshRenderer>().bounds.size.x) / 2)
            {
            }*/
        }
        if (collision.gameObject.tag == "BlockStatic")
        {
            if (transform.position.y - collision.transform.position.y < (GetComponent<MeshRenderer>().bounds.size.y + collision.gameObject.GetComponent<MeshRenderer>().bounds.size.y) / 2 &&
                transform.position.y - collision.transform.position.y > -(GetComponent<MeshRenderer>().bounds.size.y + collision.gameObject.GetComponent<MeshRenderer>().bounds.size.y) / 2)
            {
                isBumped = true;
                if (transform.position.x < collision.transform.position.x) bumpobjleft = true;
                else bumpobjleft = false;
            }
        }
        else if (transform.position.y - collision.transform.position.y >= (GetComponent<MeshRenderer>().bounds.size.y + collision.gameObject.GetComponent<MeshRenderer>().bounds.size.y) / 2 - 0.05f)
        {

            firetimes = 2;
            isOnGround = true;


        }
    }

    private void OnCollisionExit(Collision collision)
    {
        if (collision.gameObject.tag == "Ground")
        {

            isOnGround = false;
        }

        if (collision.gameObject.tag == "BlockStatic")
        {
            isOnGround = false;
            isBumped = false;

        }
    }



    bool isOnGround = true;

    bool isBumped = false;
    bool bumpobjleft = true;
}
