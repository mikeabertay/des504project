﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MyRobot : MonoBehaviour
{
    void Start()
    {

    }

    int firetimes = 3;
    private void FixedUpdate()
    {
        if (Input.GetKey(KeyCode.A)) { transform.Translate(new Vector3(-0.2f, 0, 0)); }
        else if (Input.GetKey(KeyCode.D)) { transform.Translate(new Vector3(0.2f, 0, 0)); }



        if (chargelist.Count > 0)
        {
            allcharge = Vector3.zero;

            foreach (object obj in chargelist)
            {
                DataCharge cd = obj as DataCharge;
                if (cd != null)
                {
                    if (cd.times > 0)
                    {

                        allcharge += cd.dir;
                        cd.times--;
                    }
                }
            }

            bias = 0;
            for (int i = 0; i < chargelist.Count; i++)
            {
                DataCharge cd = chargelist[i - bias] as DataCharge;
                if (cd.times <= 0)
                {
                    chargelist.RemoveAt(i - bias);

                    bias--;
                }
            }

            //if (isOnGround) if (allcharge.y < 0) allcharge.y = 0;

            transform.Translate(allcharge);
            if (transform.position.y < 0) transform.position = new Vector3(transform.position.x, 0, 0);


        }
    }
    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            if (firetimes > 0)
            {
                firetimes--;
                GameObject go = Instantiate(bullet);
                go.transform.position = transform.position;

                Vector3 dir = RayCastMonitor.rhpoint - transform.position;
                dir.z = 0;
                dir = Vector3.Normalize(dir) * 0.3f;
                go.GetComponent<MyBullet>().transDir = dir;


                go.transform.Translate(0.2f * dir);

               // AddCharge(-dir);
                /*
                                dir *= -10;

                                if (dir.y < 0) dir.y = 0;
                                transform.Translate(dir);*/
            }

        }
       
    }

    Vector3 allcharge;
    int bias;

    public GameObject bullet;


    ArrayList chargelist = new ArrayList();

    public void AddCharge(Vector3 v)
    {
        DataCharge cd = new DataCharge();
        cd.dir = v;
        cd.times = 10;
        chargelist.Add(cd);
    }

    private void OnCollisionStay(Collision collision)
    {
        if (collision.gameObject.tag == "Ground")
        {
            firetimes = 2;
            isOnGround = true;
        }
        if (collision.gameObject.tag == "BlockPush" || collision.gameObject.tag == "BlockStatic"|| collision.gameObject.tag == "BlockDestroy")
        {
            if (GetComponent<Rigidbody>().velocity == Vector3.zero)
            {
                firetimes = 2;
                isOnGround = true;
            }
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "Ground")
        {
            firetimes = 2;
            isOnGround = true;
            if (transform.position.y < 0) transform.position = new Vector3(transform.position.x, 0, 0);
        }
        if (collision.gameObject.tag == "BlockStatic")
        {

        }
    }

    private void OnCollisionExit(Collision collision)
    {
        if (collision.gameObject.tag == "Ground")
        {
 
            isOnGround = false;
        }
    }



    bool isOnGround = true;
}
