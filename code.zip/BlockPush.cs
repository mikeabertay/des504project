﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlockPush : BlockDynamic
{
    // Start is called before the first frame update
    void Start()
    {
        transform.Translate(0, 0.05f, 0);
    }

    // Update is called once per frame
    void Update()
    {

    }



    private void FixedUpdate()
    {


        

        if (pushing)
        {
            if (pushleft) { transform.Translate(-1, 0, 0); pushing = false;reference = null;  }
            else
            {
                transform.Translate(1, 0, 0); pushing = false; reference = null;
            }
        }

        if (reference == null) isDropping = true;

    //    if (staycounter != 0) { isDropping = false; staycounter = 0; }
   //     else { isDropping = true; }
        if (isDropping) transform.Translate(0, -0.05f, 0);
        else transform.position = new Vector3(transform.position.x, Mathf.Round(transform.position.y), transform.position.z);


    }




    ArrayList chargelist = new ArrayList();

    public void AddCharge(Vector3 v)
    {
        DataCharge cd = new DataCharge();
        cd.dir = v;
        cd.times = 10;
        chargelist.Add(cd);
    }

    GameObject reference;

    private void OnCollisionEnter(Collision collision)
    {
        Debug.Log("yes" + collision.gameObject.tag);
        if (collision.gameObject.tag == "Bullet")
        {

            /*               Vector3 dir = collision.gameObject.GetComponent<MyBullet>().transDir;
                            Debug.Log(dir);

                            GetComponent<Rigidbody>().AddForce(dir * 1000);
           */
            Debug.Log("qqq");
            if (collision.transform.position.x > transform.position.x) { pushing = true; pushleft = true; }//transform.Translate(-1, 0, 0);
            else { pushing = true; pushleft = false; }            //transform.Translate(1, 0, 0);

        }
        if (collision.gameObject.tag == "BlockPush")
        {



        }


        if (collision.gameObject.tag == "BlockPush" || collision.gameObject.tag == "BlockStatic" || collision.gameObject.tag == "BlockDestroy" || collision.gameObject.tag == "Ground")
        {
            if (collision.transform.position.y < transform.position.y - 0.99f)
            {
                if (collision.transform.position.x < transform.position.x + 0.1f && collision.transform.position.x > transform.position.x - 0.1f)
                {
                    isDropping = false;
                    reference = collision.gameObject;

                }
            }



        }

    }

    bool isColStay = false;

    private void OnCollisionStay(Collision collision)
    {


        if (collision.gameObject.tag == "BlockPush" || collision.gameObject.tag == "BlockStatic")
        {
            if (collision.transform.position.x > transform.position.x + 0.2f)
            {
                rigtobstacle = true;
                needSlowDown = true;
            }

            if (collision.transform.position.x < transform.position.x - 0.2f)
            {
                leftobstacle = true;
                needSlowDown = true;
            }

        }

        if (reference == collision.gameObject)
        {
            isDropping = false;

        }
        /*
        if (collision.gameObject.tag == "BlockPush" || collision.gameObject.tag == "BlockStatic" || collision.gameObject.tag == "BlockDestroy" || collision.gameObject.tag == "Ground")
        {
            if (collision.transform.position.y < transform.position.y - 0.9f)
            {
                if (collision.transform.position.x < transform.position.x + 0.1f && collision.transform.position.x > transform.position.x - 0.1f)
                {
                    //isDropping = false;
                }
            }
        }*/

        if (collision == null)
        {
            isDropping = true;
        }



        if (collision.transform.position.y < transform.position.y + 0.1f && collision.transform.position.y > transform.position.y - 0.1f)
        {
            if (collision.transform.position.x < transform.position.x + 0.1f && collision.transform.position.x > transform.position.x - 0.1f)
            {
                Debug.Log("yes");
                if (pushleft) { transform.Translate(1, 0, 0); isDropping = false; }
                else { transform.Translate(-1, 0, 0); isDropping = false; }
            }
        }




        if (collision.gameObject.tag == "BlockPush" || collision.gameObject.tag == "BlockStatic" || collision.gameObject.tag == "BlockDestroy" || collision.gameObject.tag == "Ground")
        {
            if (collision.transform.position.y < transform.position.y - 0.9f)
            {
                if (collision.transform.position.x < transform.position.x + 0.1f && collision.transform.position.x > transform.position.x - 0.1f)
                {
                    //  staycounter++;

                    reference = collision.gameObject;
                }
            }
        }
    }


    int staycounter = 1;

    private void OnCollisionExit(Collision collision)
    {

        if (collision.gameObject.tag == "BlockPush" || collision.gameObject.tag == "BlockStatic")
        {
            needSlowDown = true;
        }

        if (reference == collision.gameObject)
        {
            isDropping = true;

        }
       
         /*
        if (collision.gameObject.tag == "BlockPush" || collision.gameObject.tag == "BlockStatic" || collision.gameObject.tag == "BlockDestroy" || collision.gameObject.tag == "Ground")
        {
            if (collision.transform.position.y < transform.position.y - 0.9f)
            {
                if (collision.transform.position.x < transform.position.x + 0.1f && collision.transform.position.x > transform.position.x - 0.1f)
                {
                    isDropping = true;


                    Debug.Log(collision.gameObject.tag);
                }
            }
        }*/
    }

    bool pushleft = false;
    bool pushing = false;
    bool needSlowDown = false;

    bool leftobstacle = false;
    bool rigtobstacle = false;
    public void AddForce(Vector3 dir)
    {
        //  GetComponent<Rigidbody>().AddForce(dir * 10);
        //   Debug.Log(dir);
    }

    public bool isDropping = true;

    public void SetDropState()
    {
        Invoke("DelayDrop", 0.1f);
    }

    void DelayDrop()
    {
        isDropping = true;
    }
}
