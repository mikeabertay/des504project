﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LineGraph : MonoBehaviour
{
   
    void Start()
    {
        
    }

    void Update()
    {
        GetComponent<LineRenderer>().SetPosition(0, armAncher.transform.position);
        Vector3 p = RayCastMonitor.rhpoint;
        p.z = 0;
        GetComponent<LineRenderer>().SetPosition(1, p);
    }

    public GameObject armAncher;
}
