﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RobotArm : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        Debug.Log(transform.position);
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 p = RayCastMonitor.rhpoint;

        Vector3 deltav = p - transform.position;


        deltav.z = 0;

        Debug.Log(deltav);

        deltav = deltav.normalized;

        Quaternion q = Quaternion.LookRotation(deltav);

        transform.rotation = q;
        //Debug.Log(p.y);

        //transform.localEulerAngles = new Vector3(0,0, Mathf.Asin(p.y)*10);

       float rot = -transform.localEulerAngles.x + 90;

       if (deltav.x < 0) rot = -rot;

        rot *= dir;

        transform.localEulerAngles = new Vector3(0, 0, rot);

        transform.position = go.transform.position;

        if (Input.GetKey(KeyCode.A))
        {

            dir = -1;
        }
        else if (Input.GetKey(KeyCode.D))
        {

            dir = 1;
        }
    }

    public GameObject go;

    int dir = 1;
}
