﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DataCharge 
{
    public Vector3 dir;
    public int times;

    public enum PowerType
    {
        bullet,
    }

    public PowerType type;
}
