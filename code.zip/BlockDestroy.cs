﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlockDestroy : BlockDynamic
{
    void Start()
    {

    }

    void Update()
    {

    }

    private void FixedUpdate()
    {
        if (isDropping) transform.Translate(0, -0.05f, 0);
        if (!isDropping) transform.position = new Vector3(transform.position.x, Mathf.Round(transform.position.y), transform.position.z);
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "Bullet")
        {

            BeforeDestroy();
            Destroy(gameObject);
        }

        if (collision.gameObject.tag == "BlockPush" || collision.gameObject.tag == "BlockStatic" || collision.gameObject.tag == "BlockDestroy" || collision.gameObject.tag == "Ground")
        {
            if (collision.transform.position.y < transform.position.y - 0.9f)
            {
                if (collision.transform.position.x < transform.position.x + 0.1f && collision.transform.position.x > transform.position.x - 0.1f)
                {
                    isDropping = false;
                    reference = collision.gameObject;

                    //  Debug.Log(reference.gameObject.tag);
                    //   Debug.Log(collision.gameObject.tag);

                }
            }
        }

        if (collision.gameObject.tag == "BlockPush" || collision.gameObject.tag == "BlockDestroy")
        {
            if (collision.transform.position.y > transform.position.y + 0.9f)
            {
                if (collision.transform.position.x < transform.position.x + 0.1f && collision.transform.position.x > transform.position.x - 0.1f)
                {
                    celling = collision.gameObject;
                    // Debug.Log(celling.gameObject.tag);
                }
            }
        }
    }

    GameObject reference = null;

    GameObject celling = null;


    private void OnCollisionStay(Collision collision)
    {


        if (reference != null)
            if (reference == collision.gameObject)
            {
                isDropping = false;
            }

        if (collision == null)
        {
            isDropping = true;
        }
    }

    private void OnCollisionExit(Collision collision)
    {


        if (reference == collision.gameObject)
        {

            isDropping = true;

        }

        if (celling == collision.gameObject)
        {
            if (collision.transform.position.y > transform.position.y + 0.9f)
            {
                if (collision.transform.position.x < transform.position.x + 0.1f && collision.transform.position.x > transform.position.x - 0.1f)
                {
                    if (celling.gameObject.tag == "BlockDestroy") celling.gameObject.GetComponent<BlockDestroy>().SetDropState();
                    if (celling.gameObject.tag == "BlockPush") celling.gameObject.GetComponent<BlockPush>().SetDropState();
                }
            }
        }


    }

    void BeforeDestroy()
    {
        if (celling != null)
        {
            if (celling.transform.position.y > transform.position.y + 0.9f)
            {
                if (celling.transform.position.x < transform.position.x + 0.1f && celling.transform.position.x > transform.position.x - 0.1f)
                {
                    if (celling.tag == "BlockDestroy") celling.GetComponent<BlockDestroy>().SetDropState();
                    if (celling.tag == "BlockPush") celling.GetComponent<BlockPush>().SetDropState();
                }
            }
        }

    }

    public bool isDropping = true;

    public void SetDropState()
    {
        Invoke("DelayDrop", 0.1f);
    }

    void DelayDrop()
    {
        isDropping = true;
    }

}
