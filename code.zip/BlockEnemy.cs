﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlockEnemy : MonoBehaviour
{
    void Start()
    {
        tm.text = "";
    }

    void Update()
    {

    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "Robot")
        {
            if (tag == "BlockEnemy")
            {

                LevelJumper.Reborn();
            }
        }

        if (collision.gameObject.tag == "Bullet")
        {

            if (tag == "BlockEnemy")
            {
                if (!isDead)
                {
                    isDead = true;
                    gameObject.tag = "BlockStatic";

                    tm.text = "3";
                    Invoke("ChangeState", 1f);
                    Invoke("ChangeState2", 2f);
                    Invoke("ChangeState3", 3f);
                }
            }
        }
    }

    public TextMesh tm;

    void ChangeState()
    {
        tm.text = "2";
    }

    void ChangeState2()
    {
        tm.text = "1";
    }
    void ChangeState3()
    {
        tm.text = "0";
        GameObject go = Instantiate(boomArea);
        go.transform.position = transform.position;

        Destroy(gameObject);
    }


    public GameObject boomArea;

    bool isDead = false;
}
