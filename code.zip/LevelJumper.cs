﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelJumper : MonoBehaviour
{
    static int levelNum = 1;

    static public void Reborn()
    {
        Debug.Log("lalala");
        SceneManager.LoadScene("W5Lv" + levelNum);
    }
    void Start()
    {
        
    }

    void Update()
    {
        if (Input.GetKey(KeyCode.Alpha1)) { SceneManager.LoadScene("W4Lv1"); levelNum = 1; }
        else if (Input.GetKey(KeyCode.Alpha2)) { SceneManager.LoadScene("W4Lv2"); levelNum = 2; }
        else if (Input.GetKey(KeyCode.Alpha3)) { SceneManager.LoadScene("W4Lv3"); levelNum = 3; }
        else if (Input.GetKey(KeyCode.Alpha4)) { SceneManager.LoadScene("Lv4"); levelNum = 4; }
        else if (Input.GetKey(KeyCode.Alpha5)) { SceneManager.LoadScene("Lv5"); levelNum = 5; }
    }

    static public void LevelJump()
    {
        levelNum++;
        SceneManager.LoadScene("W5Lv"+levelNum);
    }
}
