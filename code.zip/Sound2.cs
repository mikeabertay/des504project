﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sound2 : MonoBehaviour
{
    void Start()
    {
        aus2 = GetComponent<AudioSource>();
    }

    void Update()
    {
        
    }


    public static AudioSource aus2;
}
