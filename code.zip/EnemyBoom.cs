﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBoom : MonoBehaviour
{
    void Start()
    {

        Invoke("SelfDestroy", 0.1f);
    }

    void Update()
    {
        
    }

    private void OnCollisionEnter(Collision collision)
    {
        Debug.Log("boom");

        if (collision.gameObject.tag == "Robot")
        {
            Vector3 dir = collision.transform.position - transform.position;
            dir.z = 0;
            dir = Vector3.Normalize(dir) * 0.5f;

            collision.gameObject.GetComponent<CharaCon>().AddCharge(dir/2);

            Destroy(gameObject);
        }
    }

    void SelfDestroy()
    {
        Destroy(gameObject);
    }
}
