﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LevelFactory : MonoBehaviour
{
    static public LevelFactory factory;
    void Start()
    {
        factory = this;
        foreach (Vector2 v in slist)
        {
            GameObject go = Instantiate(staticblock);
            go.transform.position = v;
        }

        foreach (Vector2 v in dlist)
        {
            GameObject go = Instantiate(destroyableblock);
            go.transform.position = v;
        }

        foreach (Vector2 v in plist)
        {
            GameObject go = Instantiate(pushableblock);
            go.transform.position = v;
        }
    }

    void Update()
    {
        
    }

    public GameObject staticblock;

    public GameObject destroyableblock;

    public GameObject pushableblock;

    public Vector2[] slist;

    public Vector2[] dlist;

    public Vector2[] plist;


    //public void Check
}
