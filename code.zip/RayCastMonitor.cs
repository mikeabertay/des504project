﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RayCastMonitor : MonoBehaviour
{
    RaycastHit rh;
    void Start()
    {
        
    }

    void Update()
    {
        Ray r = Camera.main.ScreenPointToRay(Input.mousePosition);
        if (Physics.Raycast(r, out rh, Mathf.Infinity))
        {
            rhpoint = rh.point;
           
            /*
            Debug.Log(rh.point);
            //rh.normal
            // if (OnceInsert)
            {
                //  if(rh.collider.GetComponent<Plane>()!=null)
                Debug.Log(rh.collider.GetType().Equals(typeof(MeshCollider)));
                if (rh.collider.GetType().Equals(typeof(MeshCollider)))
                {
                    GameObject go;
                    go = Instantiate(ddd);

                    go.GetComponent<Thrusters>().RayInsert(rh.point, rh.normal);
                    go.transform.parent = plane.transform;

                }
            }*/
        }
    }


   public static Vector3 rhpoint;
}
