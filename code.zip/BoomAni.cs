﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BoomAni : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {

    }

    private void FixedUpdate()
    {
        couter++;
        if (couter >= 3)
        {
            couter = 0;
            mark++;
            if (mark < atlas.Length) GetComponent<SpriteRenderer>().sprite = atlas[mark];
            else Destroy(go);
        }
    }

    int couter=0;
    int mark = 1;

    public Sprite[] atlas;


    public GameObject go;
}
